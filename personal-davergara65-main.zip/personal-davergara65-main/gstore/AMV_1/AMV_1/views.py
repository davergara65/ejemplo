from django.shortcuts import render

from django.http import HttpResponse

def index(request):

    return render(request, 'index.html',{
        'message' : 'Variable del contexto',
        'variable': 45,
        'variable2': 50.89
    })

def contact(request):

    return render(request, 'contact.html' , {
        
    })
    