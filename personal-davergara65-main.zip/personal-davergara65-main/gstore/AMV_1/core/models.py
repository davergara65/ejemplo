from tabnanny import verbose
from django.db import models

class Marca(models.Model):
    name = models.CharField(max_length=30, verbose_name="Nombre de la marca")
    
    def __str__(self)->str:
        return self.name
    
    class Meta:
        verbose_name='Marca'
        verbose_name_plural= 'Marcas'
        db_table='marca'
        ordering=['id']# Create your models here.


class Category(models.Model):
    name=models.CharField(max_length=50, verbose_name="Nombre de la categoria")
    description = models.TextField(verbose_name="Descripcion de la categoria")

    def __str__(self) ->str:
        return self.name

    class Meta:
        verbose_name='Categoria'
        verbose_name_plural='Categorias'
        db_table='categoria'
        ordering=['id']
    

class Product(models.Model):
    name = models.CharField(max_length=50, verbose_name="Nombre del producto")
    description = models.TextField(verbose_name="Descripcion del producto") 
    price=models.IntegerField(verbose_name="Precio del producto")
    #category= models.ForeignKey(Category, on_delete=models.CASCADE)
    #marca= models.ForeignKey(Marca, on_delete=models.CASCADE)
    category= models.ForeignKey(Category, on_delete=models.CASCADE)
    marca= models.ForeignKey(Marca, on_delete=models.CASCADE)
    
    def __str__(self)->str:
        return self.name
    
    class Meta:
        verbose_name='Producto'
        verbose_name_plural= 'Productos'
        db_table='producto'
        ordering=['id']# Create your models here.

