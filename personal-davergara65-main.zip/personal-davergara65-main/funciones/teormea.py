
def teorema(co: float,cd : float):
    '''Se le solicita al usuario que digite el cateto opuesto y el cateto adyasente
    para que se pueda sacar el teorema'''
    formula = ((co * co) + (cd * cd)) 
    raiz = (formula ** 0.5)
    print(f"la hipotenusa del triangulo con cateto opuesto {co}cm y cateto adyasente {cd}cm es de {raiz}cm")

help(teorema)
teorema(co = float(input("Digite el cateto opuesto: ")),
    cd = float(input("Digite el cateto adyasente: ")))



