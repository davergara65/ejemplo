from django.contrib import admin

# Register your models here.

from .models import Team,player,position,Tecnic

@admin.register(Tecnic)
class TecnicAdmin(admin.ModelAdmin):
    list_display = ['firstName','lastName','dayofborn','nacionality','Rol']
    #list_display_links = ("name", "price")
    list_editable = ["Rol","nacionality"]
    search_fields = ["firstName"]
    list_filter = ["firstName"]
    #list_per_page = 1

@admin.register(Team)
class TeamAdmin(admin.ModelAdmin):
    list_display = ['name','bandera','escudo','tecnic']
    #list_display_links = ("name")
    #list_editable = ["shield"]
    search_fields = ["name"]
    list_filter = ["name"]
    #list_per_page = 1

@admin.register(position)
class PositionAdmin(admin.ModelAdmin):
    list_display = ['name','description']
    #list_display_links = ("name", "price")
    list_editable = ["description"]
    search_fields = ["name"]
    list_filter = ["name"]
    #list_per_page = 1

@admin.register(player)
class PlayerAdmin(admin.ModelAdmin):
    list_display = ['firstName','lastName','jugador','position','number','captain','team']
    #list_display_links = ("name", "price")
    list_editable = ["number","captain"]
    search_fields = ["firstName"]
    list_filter = ["firstName"]
    #list_per_page = 1
