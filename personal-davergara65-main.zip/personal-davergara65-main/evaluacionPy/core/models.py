from tabnanny import verbose
from unicodedata import name
from django.db import models
from django.utils.html import format_html

# Create your models here.

class Tecnic(models.Model):
    firstName = models.CharField(max_length=25, verbose_name="Nombre del tecnico")
    lastName = models.CharField(max_length=25, verbose_name="Apellido del tecnico")
    dayofborn = models.DateField(verbose_name="Dia de nacimiento")
    nacionality = models.CharField(max_length=25, verbose_name="Nacion del tecnico")
    R=[
        ('tecnico','tecnico'),
        ('asistente','asistente'),
        ('médico','médico'),
        ('preparador','preparador'),
    ]
    Rol = models.CharField(max_length=25,choices=R,help_text="es titular")

    def __str__(self) -> str:   
        return self.firstName

    class Meta:
        verbose_name = 'Tecnico'
        verbose_name_plural = 'Tecnicos'
        db_table = 'Tecnico'
        ordering = ['id']
        

class Team(models.Model):
    name = models.CharField(max_length=25, verbose_name="Nombre del equipo")
    imageFlag = models.ImageField(upload_to='media', null=True, blank=False, verbose_name="Bandera")
    imageShield = models.ImageField(upload_to='media', null=True, blank=False, verbose_name="Escudo")
    tecnic = models.ForeignKey(Tecnic, on_delete=models.CASCADE,verbose_name="Tecnico")
    

    def __str__(self) -> str:
        return self.name

    class Meta:
        verbose_name = 'Equipo'
        verbose_name_plural = 'Equipos'
        db_table = 'Equipo'
        ordering = ['name']
            
    def bandera(self):
        return format_html('<img src={} width="100" /> ', self.imageFlag.url)

    def escudo(self):
        return format_html('<img src={} width="100" /> ', self.imageShield.url)

class position(models.Model):
    name = models.CharField(max_length=25, verbose_name="Nombre de la posicion")
    description = models.TextField(verbose_name="Descripcion de la posicion")

    def __str__(self) -> str:
        return self.name

    class Meta:
        verbose_name = 'Posicion'
        verbose_name_plural = 'Posiciones'
        db_table = 'Posicion'
        ordering = ['id']

class player(models.Model):
    firstName = models.CharField(max_length=25, verbose_name="Nombre del jugador")
    lastName = models.CharField(max_length=25, verbose_name="Apellido del jugador")
    imagePlayer = models.ImageField(upload_to='media', null=True, blank=False, verbose_name="Jugador")
    dayofborn = models.DateField(max_length=25, verbose_name="Dia de nacimiento")
    position = models.OneToOneField(
        position,
        on_delete=models.CASCADE,
        primary_key=True,
        verbose_name="Posicion del jugador"
    )
    number = models.IntegerField(verbose_name="Numero del jugador")
    Cap=[
        ('si','si'),
        ('no','no'),
    ]
    captain = models.CharField(max_length=25,choices=Cap,help_text="es titular")
    team = models.ForeignKey(Team, on_delete=models.CASCADE)

    def __str__(self) -> str:
        return self.firstName

    class Meta:
        verbose_name = 'Jugador'
        verbose_name_plural = 'Jugadores'
        db_table = 'Jugador'
        ordering = ['number']
            
    def jugador(self):
        return format_html('<img src={} width="100" /> ', self.imagePlayer.url)


    






                
