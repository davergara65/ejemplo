
l = int(input("Inserte la cantidad de labiales que va a comprar: "))
pre = float(input("Inserte el precio: "))

if l <= 5:
    pago = pre * l
    print("Debe pagar: ", pago)
elif l <= 10:
    pago = (pre * l) - (pre*0.05) 
    print("Debe pagar: ", pago)
else:
    pago = (pre * l) - (pre*0.08)
    print("Debe pagar: ",pago)