num1 = float(input("Inserte el primer numero "))
num2 = float(input("Inserte el segundo numero "))

if num1 > num2:
    print("el numero ",num1, " es mayor a el numero ",num2)
elif num1 < num2:
    print("el numero ",num2, " es mayor a el numero ",num1)
else:
    print("los dos numeros son iguales")