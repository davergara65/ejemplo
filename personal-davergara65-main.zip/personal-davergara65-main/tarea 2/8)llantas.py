r = int(input("Cantidad de llantas que quiere comprar: "))

if r <= 5:
    pre = r * 240000
    print("debe pagar ", pre)
elif r <= 7:
    pre = r * 221000
    print("debe pagar ", pre)
else:
    pre = r * 180000
    print("debe pagar ", pre)