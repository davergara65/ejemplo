
num = float(input("Inserte un numero "))

if num < 0:
    print("el numero ", num, " es negativo")
elif num > 0:
    print("el numero ", num, " es positivo")
else:
    print("el numero es ", num)
