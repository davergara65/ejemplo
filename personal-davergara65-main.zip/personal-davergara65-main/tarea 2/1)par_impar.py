from ast import Num
from operator import mod

num = float(input("Inserte un numero: "))

mod = 5%2

if num % 2 == 0:
    print("el numero es par")
else:
    print("el numero es impar")
