c = float(input("digite la cuenta para saber la forma de pago: "))

if c < 150000:
    print("la forma de pago es en efectivo")
elif c >=15000 and c <= 300000:
    print("la forma de pago es con celular")
elif c >= 300000 and c <= 600000:
    print("la forma de pago es con tarjeta de debito")
else:
    print("la forma de pago es con tarjeta de credito")