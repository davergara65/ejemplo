print("Digite su genereo con H para hombre y con M para mujer EN MAYUSUCULA")
g = input()

if g == "M":
    a = int(input("Digite sus años "))
    pul = ((220 - a)/10)
    print("la cantidad de pulsaciones que deberia tener a su edad es: ",pul)
elif g == "H":
    a = int(input("Digite sus años "))
    pul = ((210 - a)/10)
    print("la cantidad de pulsaciones que deberia tener a su edad es: ",pul)
else:
    print("vuelva a intenarlo")