m = int(input("Digite el tamaño de pizza que quiere \n1 Precio 15000 \n2 Precio 24000 \n3 Precio 36000 \ny cada ingrediente adicional cuesta 4000\n"))

if m == 1:
    ia = int(input("Cuantos ingredientes adicionales desea: "))
    pre = (15000 + (ia * 4000))
    print("la cantidad que debe pagar es de: ", pre) 
if m == 2:
    ia = int(input("Cuantos ingredientes adicionales desea: "))
    pre = (24000 + (ia * 4000)) 
    print("la cantidad que debe pagar es de: ", pre) 
if m == 3:
    ia = int(input("Cuantos ingredientes adicionales desea: "))
    pre = (36000 + (ia * 4000))
    print("la cantidad que debe pagar es de: ", pre) 