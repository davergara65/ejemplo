a = float(input("Numero 1: "))
b = float(input("Numero 2: "))
c = float(input("Numero 3: "))

if a > b and b > c:
    print(a,",",b,",",c)
elif b > a and a > c:
    print(b,",",a,",", c)
elif c > a and a > b:
    print(c,",",a,",",b)
elif c > b and b > a:
    print(c,",",b,",",a)
elif a > c and c > b:
    print(a,",",c,",",b)
elif b > c and c > a:
    print(b,",",c,",",a)
else:
    print("todos los numeros son iguales")