print("Inserte sus notas del 0 al 5")

n1 = float(input("Nota 1: "))
n2 = float(input("Nota 2: "))
n3 = float(input("Nota 3: "))
n4 = float(input("Nota 4: "))
n5 = float(input("Nota 5: "))

nota = ((n1 + n2 + n3 +n4 + n5) / 5)

if nota >= 3:
    print("Usted aprobo con una nota de: ", nota)
else:
    print("Uste perdio con una nota de ", nota)
