print("Forma de saber el indice de masa corporal")
p = float(input("Inserte el peso Kg: "))
t = float(input("Inserte la talla: "))

imc = (p/(t*t))

if imc < 20:
    print("Su IMC es de ", imc ,"Usted esta desnutrido")
elif imc < 25:
    print("Su IMC es de ", imc ,"Usted esta normal")
elif imc < 30:
    print("Su IMC es de ", imc ,"Usted esta con sobre peso")
elif imc < 35:
    print("Su IMC es de ", imc ,"Usted esta con obesidad grado 1")
elif imc < 40:
    print("Su IMC es de ", imc ,"Usted esta con obesidad grado 2")
else:
    print("Su IMC es de ", imc ,"Usted esta con obesidad grado 3")