from cmath import pi


print("Inserte la figura que quiere sacar el area")
print("1 Cuadrado")
print("2 Rectangulo")
print("3 triangulo")
print("4 Circulo")
print("5 Rombo")
print("6 Trapecio")

menu = int(input("inserte numero "))

if menu > 0 and menu <= 6:
    if menu == 1:  # CUADRADO
        cu = float(input("Inserte el lado del cuadrado "))
        Re = (cu * cu)
        print("El area del cuadrado es: ",Re)
    elif menu == 2: # RECTANGULO
        b = float(input("Inserte la base del Rectangulo "))
        a = float(input("Inserte la Altura del Rectangulo "))
        Re = (a * b)
        print("El area del Rectangulo es: ",Re)
    elif menu == 3: #TRIANGULO
        b = float(input("Inserte la base del Triangulo "))
        a = float(input("Inserte la Altura del Triangulo "))
        Re = ((a * b)/2)
        print("El area del Triangulo es: ",Re)
    elif menu == 4: #CIRCULO
        r = float(input("Inserte el radio del Circulo "))
        Re = (r * r) * pi
        print("El area del Circulo es: ",Re)
    elif menu == 5: #ROMBO
        d1 = float(input("Inserte el diagonal mayor del Rombo "))
        d2 = float(input("Inserte el diagonal menor del Rombo "))
        Re = ((d1 * d2)/2)
        print("El area del Rombo es: ",Re)
    elif menu == 6: #TRAPECIO
        b1 = float(input("Inserte la base mayor del Trapecio "))
        b2 = float(input("Inserte la base menor del Trapecio "))
        h = float(input("Inserte la altura del Trapecio "))
        Re = (((b1 + b2)/2)* h)
        print("El area del Rombo es: ",Re)
else:
    print("Esa opcion no esta dentro del menu")