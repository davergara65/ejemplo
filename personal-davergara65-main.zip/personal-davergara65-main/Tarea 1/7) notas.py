
# cantidad de respuestas correcta a nota

# se pide la cantidad de respuestas correctas al usuario

print("el examen tiene un maximo de 120 respuestas")

res = int(input("Inserte la cantidad de respuestas correctas: "))

# Operacion

o = (50/120)

nota = (res * o)

#resultado

print("la nota de este examen es : ", nota)
