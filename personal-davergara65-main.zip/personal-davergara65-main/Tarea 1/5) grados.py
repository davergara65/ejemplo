
# inserte los grados en Celsius

print("\nse le pedira una temperatura de Celsius y esta sera convertida a fahrenheit y a kelvin")

# se pide la temperatura en Celsius

c = float(input("inserte la temperatura Celsius: "))

# Formula de C a F

f = ((1.8 * c) + 32)

# Formula de C a K

k = (c + 273.15)

# se muestran los resultados

#C a F

print(f"La conversion de C a F es : {f}") 

#C a K

print(f"La conversion de C a K es : {k}") 

