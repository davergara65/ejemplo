
cm = float(input("digite una medida de cm : "))

mm = (cm * 10)
dm = (cm / 10)
dam = (cm / 1000)
hm = (cm / 10000)
km = (cm / 100000)

print("centimetros : ", cm ," cm",
"\nmilimetros : ", mm ," mm",
"\ndecimetro : ", dm," dm",
"\ndecametro :", dam," dam",     
"\nhectometro : ", hm," hm",
" \nkilometros : " , km ," km")
