
print("Insertar angulo para convertirlo en radiane")

# Grados a radianes

gra = float(input("Inserte un angulo(grados): "))

#formula

rad = ((gra * 3.1416)/180)

print(rad)