
print("el numero 1 sumara hasta llegar a 100")

numero = 0
num = 1

while num <= 100:
    print(numero)
    numero = numero + num
    num += 1
print("La suma de los numero es de :", numero)