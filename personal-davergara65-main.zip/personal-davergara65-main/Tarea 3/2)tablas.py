
contador10 = 10
multi = 0

while contador10 < 100:
    multi = multi + 1
    contador = 1
    contador1 = 1
    contador2 = 2
    contador3 = 3
    contador4 = 4
    contador5 = 5
    contador6 = 6
    contador7 = 7
    contador8 = 8
    contador9 = 9
    contador10 = 10
    contador *= multi
    contador1 *= multi
    contador2 *= multi
    contador3 *= multi
    contador4 *= multi
    contador5 *= multi
    contador6 *= multi
    contador7 *= multi
    contador8 *= multi
    contador9 *= multi
    contador10 *= multi
    print("Contador: ",contador,contador1,contador2,contador3,contador4,contador5,contador6,contador7,contador8,contador9,contador10)
print("Fin ciclo")