
print("Inserte numeros para sacara el promedio y cuando haya acabado ponga 0 para terminar")

numero = float(input("Numero "))
if numero == 0:
    print("No puede poner el numero 0 de primeras")

else:
    pro = 1
    numero = numero
    print(numero,pro)
    while True:
        num = numero
        numero = float(input("Numero "))
        if numero != 0:
            numero = num + numero
            pro = pro + 1
            print(numero,pro)
        else:
            numero = num + numero
            promedio= numero / pro
            print("el promedio de los numeros sumados es: ", promedio)
            break
    
    

