print("Inserte numeros para sacara el promedio y cuando haya acabado ponga 0 para terminar")

numero = float(input("Numero "))

numero = numero
print(numero)
while True:
    num = numero
    numero = float(input("Numero "))
    if numero > num:
        print("el numero mayor es: ", numero)
        numero = numero
    elif num > numero:
        print("el numero mayor es: ", num)
        numero = num
    else:
        print("Los dos numeros son iguales")
        break
        
    