from random import randint, random


dado = 0

while dado != 3:
    
    if dado != 3:
        dado = randint(1,6)
        print("El numero del dado es: ", dado)
    else:
        break
    print("Ha finalizado")    

