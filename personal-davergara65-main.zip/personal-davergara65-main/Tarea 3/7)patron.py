
ast = 5

for i in range(1, ast + 1):
    for f in range(i):
        print('* ', end='')
    print()

for i in range(ast - 1, 0, -1):
    for f in range(i):
        print('* ', end='')
    print()